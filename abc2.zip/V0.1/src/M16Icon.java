
public class M16Icon extends Sprite{

	public M16Icon() {
		images = new String[]{"m-16-icon.png"};
		id = "m-16 icon";
	}

}
