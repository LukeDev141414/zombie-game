
public class Block extends Sprite {

	public Block() {
		images =  new String[]{"block2.png"};
		id = "block";
	}

}
