import java.util.*;
public class Resources {
	public static String playerLeft = "player_right.png";
	public static String playerRight = "player_left.png";
	public static String playerUp = "player_up.png";
	public static String playerDown = "player_down.png";
	public static String backgroundImage = "background.png";
	public static String startScreen = "startscreen.png";
	public static String normalZombieImage = "nz.png";
	public static String fastZombieImage = "fz.png";
	public static String glockBulletImageLeft = "glock_bullet_left.png";
	public static String glockBulletImageUp = "glock_bullet_up.png";
	public static String glockBulletImageRight = "glock_bullet_right.png";
	public static String glockBulletImageDown = "glock_bullet_down.png";
 	public Resources() {
		
	}

}
