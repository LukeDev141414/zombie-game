import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;

public class StartCreen extends Sprite{
	
	public StartCreen() {
		
		images = new String[]{Resources.startScreen};
		x=0;
		y=0;
	}
	

}
