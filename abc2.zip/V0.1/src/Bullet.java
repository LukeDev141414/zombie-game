/**
 * 
 */

/**
 * @author �ukasz
 *
 */
public class Bullet extends Sprite {

	/**
	 * 
	 */
	public Bullet() {
		images = new String[]{};
	}

}
