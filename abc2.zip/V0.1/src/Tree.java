
public class Tree extends Sprite{

	public Tree() {
		images = new String[]{"tree.png"};
		id="block";
	}

}
