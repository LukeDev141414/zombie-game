
public class Variables {
	public static int width = 800;
	public static int height = 600;
	public static int fps = 50;
	public static String title;
	public static int playerLife = 100;
    public static boolean visible = true;
    public static int pSpeed = 3;
    public static int glockDelay = 25;
    public static String playerWeapon = "glock";
    public static int zombieSpeed = 1;
	public Variables() {
		// TODO Auto-generated constructor stub
	}

}
