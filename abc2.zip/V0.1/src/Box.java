
public class Box extends Sprite{

	public Box() {
		id = "block2";
		images = new String[]{"block.png"};
	}

}
