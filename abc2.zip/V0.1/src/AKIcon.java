
public class AKIcon extends Sprite{

	public AKIcon() {
		images = new String[]{"ak-47-icon.png"};
		id = "ak-47 icon";
	}

}
